﻿Imports System.ComponentModel
Imports System.Runtime.InteropServices

Namespace AsmTest

    Friend Class NativeMethods

        Public Const MEM_COMMIT As UInteger = &H1000

        Public Const MEM_RESERVE As UInteger = &H2000

        Public Const PAGE_EXECUTE_READ As UInteger = &H20

        '''<summary>
        ''' 写入内存
        ''' </summary>
        ''' <param name="hProcess">进程句柄</param>
        ''' <param name="lpBaseAddress">地址</param>
        ''' <param name="lpBuffer">要写入的内容</param>
        ''' <param name="nSize">写入内容的大小</param>
        ''' <param name="lpNumberOfBytesWritten">实际写入大小</param>
        ''' <returns></returns>
        <DllImport("kernel32.dll", ExactSpelling:=True, SetLastError:=True)>
        Public Shared Function WriteProcessMemory(ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByVal lpBuffer As Byte(), ByVal nSize As UInteger, ByRef lpNumberOfBytesWritten As Integer) As Boolean
        End Function

        '''<summary>
        ''' 在当前进程中分配内存
        ''' </summary>
        ''' <param name="lpAddress">指定一个地址用于分配内存（如果为IntPtr.Zero则自动分配）</param>
        ''' <param name="dwSize">要分配内存的大小</param>
        ''' <param name="flAllocationType">内存分配选项</param>
        ''' <param name="flProtect">内存保护选项</param>
        ''' <returns></returns>
        <DllImport("kernel32.dll", ExactSpelling:=True, SetLastError:=True)>
        Public Shared Function VirtualAlloc(ByVal lpAddress As IntPtr, ByVal dwSize As UInteger, ByVal flAllocationType As UInteger, ByVal flProtect As UInteger) As IntPtr
        End Function
    End Class

    '''<summary>
    ''' 随机数生成器（需要CPU支持，可用于Intel Ivy Bridge以及之后架构的处理器，AMD 2015年6月以及之后架构的处理器）
    ''' </summary>
    Public Class TrueRandom

        Private Shared _isInitialized As Boolean

        Private Shared _isSupported As Boolean

        Private Delegate Function GetEcxNativeCall() As UInteger

        Private Delegate Function Rand16NativeCall() As UShort

        Private Shared Rand16Native As Rand16NativeCall

        Private Delegate Function Rand32NativeCall() As UInteger

        Private Shared Rand32Native As Rand32NativeCall

        Private Delegate Function Rand64NativeCall() As ULong

        Private Shared Rand64Native As Rand64NativeCall

        '''<summary>
        ''' 初始化
        ''' </summary>
        ''' <returns>CPU支持将返回true，cpu不支持将返回false</returns>
        Public Shared Function Initialize() As Boolean
            Dim pAsm As IntPtr
            Dim bytAsm As Byte()
            Dim num As Integer
            _isInitialized = True
            IsSupported()
            '获取是否支持
            If Not (_isSupported) Then
                Return False
            End If

            pAsm = NativeMethods.VirtualAlloc(IntPtr.Zero, 100, NativeMethods.MEM_COMMIT Or NativeMethods.MEM_RESERVE, NativeMethods.PAGE_EXECUTE_READ)
            bytAsm = New Byte() {&HF, &HC7, &HF0, &HC3}
            If Not (NativeMethods.WriteProcessMemory(CType((-1), IntPtr), pAsm, bytAsm, CType(bytAsm.Length, UInteger), num)) Then
                Throw New Win32Exception()
            End If

            Rand16Native = DirectCast(Marshal.GetDelegateForFunctionPointer(pAsm, GetType(Rand16NativeCall)), Rand16NativeCall)
            pAsm += bytAsm.Length
            bytAsm = New Byte() {&HF, &HC7, &HF0, &HC3}
            If Not (NativeMethods.WriteProcessMemory(CType((-1), IntPtr), pAsm, bytAsm, CType(bytAsm.Length, UInteger), num)) Then
                Throw New Win32Exception()
            End If

            Rand32Native = DirectCast(Marshal.GetDelegateForFunctionPointer(pAsm, GetType(Rand32NativeCall)), Rand32NativeCall)
            pAsm += bytAsm.Length
            bytAsm = New Byte() {&H48, &HF, &HC7, &HF0, &HC3}
            If Not (NativeMethods.WriteProcessMemory(CType((-1), IntPtr), pAsm, bytAsm, CType(bytAsm.Length, UInteger), num)) Then
                Throw New Win32Exception()
            End If

            Rand64Native = DirectCast(Marshal.GetDelegateForFunctionPointer(pAsm, GetType(Rand64NativeCall)), Rand64NativeCall)
            '通过函数指针获取委托

            Return True
        End Function

        '''<summary>
        ''' 获取CPU是否支持RdRand
        ''' </summary>
        Private Shared Sub IsSupported()
            Dim pAsm As IntPtr
            Dim bytAsm As Byte()
            Dim ecx As UInteger
            Dim num As Integer
            ecx = 0
            If Environment.Is64BitProcess Then
                bytAsm = New Byte() {&H40, &H55, &H53, &H48, &H83, &HEC, &H68, &H48, &H8B, &HEC, &HB8, &H4, &H0, &H0, &H0, &H48, &H6B, &HC0, &H0, &H48, &H8D, &H44, &H5, &H0, &H48, &H89, &H45, &H50, &HB8, &H1, &H0, &H0, &H0, &H33, &HC9, &HF, &HA2, &H4C, &H8B, &H45, &H50, &H41, &H89, &H0, &H41, &H89, &H58, &H4, &H41, &H89, &H48, &H8, &H41, &H89, &H50, &HC, &HB8, &H4, &H0, &H0, &H0, &H48, &H6B, &HC0, &H2, &H8B, &H44, &H5, &H0, &H48, &H8D, &H65, &H68, &H5B, &H5D, &HC3}
                '真·C++代码（生成的汇编转换成的机器码）
            Else
                bytAsm = New Byte() {&H55, &H8B, &HEC, &H83, &HEC, &H50, &H53, &H56, &H57, &HB8, &H4, &H0, &H0, &H0, &H6B, &HC8, &H0, &H8D, &H74, &HD, &HF0, &HB8, &H1, &H0, &H0, &H0, &H33, &HC9, &HF, &HA2, &H89, &H6, &H89, &H5E, &H4, &H89, &H4E, &H8, &H89, &H56, &HC, &HB8, &H4, &H0, &H0, &H0, &HD1, &HE0, &H8B, &H44, &H5, &HF0, &H5F, &H5E, &H5B, &H8B, &HE5, &H5D, &HC3}
            End If

            pAsm = NativeMethods.VirtualAlloc(IntPtr.Zero, CType(bytAsm.Length, UInteger), NativeMethods.MEM_COMMIT Or NativeMethods.MEM_RESERVE, 64)
            '分配内存，用于存储机器码
            If Not (NativeMethods.WriteProcessMemory(CType((-1), IntPtr), pAsm, bytAsm, CType(bytAsm.Length, UInteger), num)) Then
                Throw New Win32Exception()
            End If

            Dim GetEcxNative As GetEcxNativeCall = DirectCast(Marshal.GetDelegateForFunctionPointer(pAsm, GetType(GetEcxNativeCall)), GetEcxNativeCall)
            ecx = GetEcxNative()
            _isSupported = (ecx And &H40000000) = &H40000000
        End Sub

        '''<summary>
        ''' 产生一个16位随机数
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function Rand16() As UShort
            If Not (_isInitialized) Then
                Throw New InvalidOperationException()
            End If

            If Not (_isSupported) Then
                Throw New NotSupportedException()
            End If

            Return Rand16Native()
        End Function

        '''<summary>
        ''' 产生一个32位随机数
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function Rand32() As UInteger
            If Not (_isInitialized) Then
                Throw New InvalidOperationException()
            End If

            If Not (_isSupported) Then
                Throw New NotSupportedException()
            End If

            Return Rand32Native()
        End Function

        '''<summary>
        ''' 产生一个64位随机数
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function Rand64() As ULong
            If Not (_isInitialized) Then
                Throw New InvalidOperationException()
            End If

            If Not (_isSupported) Then
                Throw New NotSupportedException()
            End If

            If Environment.Is64BitProcess Then
                Return Rand64Native()
            Else
                Dim bytLong As Byte()
                bytLong = New Byte(8) {}
                BitConverter.GetBytes(Rand32Native()).CopyTo(bytLong, 0)
                BitConverter.GetBytes(Rand32Native()).CopyTo(bytLong, 4)
                Return BitConverter.ToUInt64(bytLong, 0)
            End If
        End Function
    End Class
End Namespace
